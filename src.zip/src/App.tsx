
import Navigation from './components/Navigation';
import './App.css';

function App() {
  return (
    <main className="app-layout">
      <Navigation />
      {/* Content panel later */}
    </main>
  );
}

export default App;
